# CV Wine Merchants Website Preview

This folder contains a standalone static website preview.

## Fastest way to get a public preview link

1. Go to Netlify Drop: https://app.netlify.com/drop
2. Drag this whole folder or the ZIP file onto the page.
3. Netlify will generate a public preview URL.
4. Send that URL to anyone. They do not need a ChatGPT account.

## Files

- `index.html` — complete one-page website preview.
- Uses Tailwind via CDN for quick previewing.

## Before final launch

Replace placeholders:
- Phone number
- Email address
- Exact street address
- Google Maps URL
- Verified trading hours
- Liquor licence / responsible service compliance text
